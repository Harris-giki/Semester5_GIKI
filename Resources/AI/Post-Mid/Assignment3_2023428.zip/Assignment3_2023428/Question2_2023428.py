import numpy as np
import matplotlib.pyplot as plt
import networkx as nx
from typing import Dict, List, Tuple

class MarsRoverMDP:
    def __init__(self):
        # State definitions
        self.HILL_TOP_STATE = 0
        self.ROLLING_DOWN_STATE = 1
        self.HILL_BOTTOM_STATE = 2
        
        self.state_descriptions = {
            self.HILL_TOP_STATE: "Top of Hill",
            self.ROLLING_DOWN_STATE: "Rolling Down",
            self.HILL_BOTTOM_STATE: "Bottom of Hill"
        }
        
        # Action definitions
        self.DRIVE_ACTION = 1
        self.NO_DRIVE_ACTION = 0
        
        self.action_descriptions = {
            self.DRIVE_ACTION: "Drive",
            self.NO_DRIVE_ACTION: "Don't Drive"
        }
        
        # Energy collection and costs
        self.energy_at_top = 3
        self.energy_elsewhere = 1
        self.driving_energy_cost = 1
        
        self.discount_rate = 0.8
        
        # Transition probabilities: [state][action][next_state]
        self.transition_probabilities = self._initialize_transitions()
        
        # Reward function
        self.reward_structure = self._initialize_rewards()
        
    def _initialize_transitions(self):
        """Initialize state transition probability matrix"""
        transition_matrix = {}
        
        # Top of hill transitions
        transition_matrix[self.HILL_TOP_STATE] = {
            self.DRIVE_ACTION: {
                self.HILL_TOP_STATE: 0.9,
                self.ROLLING_DOWN_STATE: 0.1,
                self.HILL_BOTTOM_STATE: 0.0
            },
            self.NO_DRIVE_ACTION: {
                self.HILL_TOP_STATE: 0.7,
                self.ROLLING_DOWN_STATE: 0.3,
                self.HILL_BOTTOM_STATE: 0.0
            }
        }
        
        # Rolling down transitions
        transition_matrix[self.ROLLING_DOWN_STATE] = {
            self.DRIVE_ACTION: {
                self.HILL_TOP_STATE: 0.3,
                self.ROLLING_DOWN_STATE: 0.6,
                self.HILL_BOTTOM_STATE: 0.1
            },
            self.NO_DRIVE_ACTION: {
                self.HILL_TOP_STATE: 0.0,
                self.ROLLING_DOWN_STATE: 0.0,
                self.HILL_BOTTOM_STATE: 1.0
            }
        }
        
        # Bottom of hill transitions
        transition_matrix[self.HILL_BOTTOM_STATE] = {
            self.DRIVE_ACTION: {
                self.HILL_TOP_STATE: 0.6,
                self.ROLLING_DOWN_STATE: 0.0,
                self.HILL_BOTTOM_STATE: 0.4
            },
            self.NO_DRIVE_ACTION: {
                self.HILL_TOP_STATE: 0.0,
                self.ROLLING_DOWN_STATE: 0.0,
                self.HILL_BOTTOM_STATE: 1.0
            }
        }
        
        return transition_matrix
        
    def _initialize_rewards(self):
        """Initialize reward structure for state-action pairs"""
        reward_matrix = {}
        
        for current_state in [self.HILL_TOP_STATE, self.ROLLING_DOWN_STATE, self.HILL_BOTTOM_STATE]:
            reward_matrix[current_state] = {}
            
            for current_action in [self.DRIVE_ACTION, self.NO_DRIVE_ACTION]:
                # Calculate energy collected
                if current_state == self.HILL_TOP_STATE:
                    energy_collected = self.energy_at_top
                else:
                    energy_collected = self.energy_elsewhere
                    
                # Subtract driving cost if applicable
                if current_action == self.DRIVE_ACTION:
                    total_reward = energy_collected - self.driving_energy_cost
                else:
                    total_reward = energy_collected
                    
                reward_matrix[current_state][current_action] = total_reward
                
        return reward_matrix
        
    def calculate_expected_value(self, current_state, chosen_action, state_values):
        """Calculate expected value for a state-action pair"""
        immediate_reward = self.reward_structure[current_state][chosen_action]
        future_value_expectation = 0
        
        for next_state, transition_prob in self.transition_probabilities[current_state][chosen_action].items():
            future_value_expectation += transition_prob * state_values[next_state]
            
        return immediate_reward + self.discount_rate * future_value_expectation
        
    def visualize_mdp_graph(self):
        """Create visual representation of MDP"""
        graph_structure = nx.DiGraph()
        
        # Add state nodes
        for state_id, state_name in self.state_descriptions.items():
            graph_structure.add_node(state_name)
            
        # Add edges with transition probabilities
        for current_state in self.transition_probabilities:
            for action_taken in self.transition_probabilities[current_state]:
                for next_state, probability in self.transition_probabilities[current_state][action_taken].items():
                    if probability > 0:
                        current_state_name = self.state_descriptions[current_state]
                        next_state_name = self.state_descriptions[next_state]
                        action_label = self.action_descriptions[action_taken]
                        reward_value = self.reward_structure[current_state][action_taken]
                        
                        edge_description = f"{action_label}\nP={probability}\nR={reward_value}"
                        graph_structure.add_edge(current_state_name, next_state_name, 
                                                label=edge_description, weight=probability)
        
        plt.figure(figsize=(14, 10))
        node_layout = nx.spring_layout(graph_structure, k=2, iterations=50)
        
        nx.draw(graph_structure, node_layout, with_labels=True, node_color='lightblue',
                node_size=3000, font_size=10, font_weight='bold', 
                arrows=True, arrowsize=20, edge_color='gray', width=2)
        
        edge_labels_dict = nx.get_edge_attributes(graph_structure, 'label')
        nx.draw_networkx_edge_labels(graph_structure, node_layout, edge_labels_dict, 
                                     font_size=8)
        
        plt.title("Mars Rover MDP - State Transition Diagram", fontsize=16, fontweight='bold')
        plt.axis('off')
        plt.tight_layout()
        plt.savefig('mars_rover_mdp_diagram.png', dpi=300, bbox_inches='tight')
        print("MDP diagram saved as 'mars_rover_mdp_diagram.png'")
        plt.show()


class ValueIterationSolver:
    def __init__(self, mdp_model: MarsRoverMDP):
        self.mdp = mdp_model
        self.state_value_history = []
        
    def execute_value_iteration(self, maximum_iterations=60, convergence_threshold=1e-6):
        """Perform value iteration algorithm"""
        print("\n" + "="*70)
        print("VALUE ITERATION ALGORITHM")
        print("="*70)
        
        # Initialize all state values to zero
        current_state_values = {
            self.mdp.HILL_TOP_STATE: 0.0,
            self.mdp.ROLLING_DOWN_STATE: 0.0,
            self.mdp.HILL_BOTTOM_STATE: 0.0
        }
        
        iteration_number = 0
        
        while iteration_number < maximum_iterations:
            previous_state_values = current_state_values.copy()
            self.state_value_history.append(current_state_values.copy())
            
            print(f"\nIteration {iteration_number}:")
            for state_id, state_name in self.mdp.state_descriptions.items():
                print(f"  V({state_name}) = {current_state_values[state_id]:.6f}")
            
            # Update values for all states
            for current_state in [self.mdp.HILL_TOP_STATE, self.mdp.ROLLING_DOWN_STATE, 
                                 self.mdp.HILL_BOTTOM_STATE]:
                action_values = []
                
                for action_choice in [self.mdp.DRIVE_ACTION, self.mdp.NO_DRIVE_ACTION]:
                    expected_value = self.mdp.calculate_expected_value(
                        current_state, action_choice, previous_state_values
                    )
                    action_values.append(expected_value)
                    
                current_state_values[current_state] = max(action_values)
            
            # Check convergence
            maximum_change = max(abs(current_state_values[s] - previous_state_values[s]) 
                                for s in current_state_values)
            
            if maximum_change < convergence_threshold and iteration_number >= maximum_iterations:
                print(f"\nConverged after {iteration_number} iterations")
                break
                
            iteration_number += 1
        
        # Extract optimal policy
        optimal_policy_mapping = self.extract_optimal_policy(current_state_values)
        
        print("\n" + "="*70)
        print("FINAL VALUE ITERATION RESULTS")
        print("="*70)
        print("\nOptimal State Values:")
        for state_id, state_name in self.mdp.state_descriptions.items():
            print(f"  V*({state_name}) = {current_state_values[state_id]:.6f}")
            
        print("\nOptimal Policy:")
        for state_id, state_name in self.mdp.state_descriptions.items():
            action_name = self.mdp.action_descriptions[optimal_policy_mapping[state_id]]
            print(f"  π*({state_name}) = {action_name}")
        
        return current_state_values, optimal_policy_mapping
        
    def extract_optimal_policy(self, state_values):
        """Derive optimal policy from state values"""
        optimal_actions = {}
        
        for current_state in [self.mdp.HILL_TOP_STATE, self.mdp.ROLLING_DOWN_STATE, 
                             self.mdp.HILL_BOTTOM_STATE]:
            best_action = None
            best_value = -float('inf')
            
            for action_choice in [self.mdp.DRIVE_ACTION, self.mdp.NO_DRIVE_ACTION]:
                expected_value = self.mdp.calculate_expected_value(
                    current_state, action_choice, state_values
                )
                
                if expected_value > best_value:
                    best_value = expected_value
                    best_action = action_choice
                    
            optimal_actions[current_state] = best_action
            
        return optimal_actions


class PolicyIterationSolver:
    def __init__(self, mdp_model: MarsRoverMDP):
        self.mdp = mdp_model
        self.policy_evolution_history = []
        self.value_evolution_history = []
        
    def evaluate_current_policy(self, policy_mapping, convergence_threshold=1e-6):
        """Policy evaluation step"""
        current_state_values = {
            self.mdp.HILL_TOP_STATE: 0.0,
            self.mdp.ROLLING_DOWN_STATE: 0.0,
            self.mdp.HILL_BOTTOM_STATE: 0.0
        }
        
        evaluation_iteration = 0
        max_evaluation_iterations = 1000
        
        while evaluation_iteration < max_evaluation_iterations:
            previous_values = current_state_values.copy()
            
            for current_state in [self.mdp.HILL_TOP_STATE, self.mdp.ROLLING_DOWN_STATE,
                                 self.mdp.HILL_BOTTOM_STATE]:
                selected_action = policy_mapping[current_state]
                current_state_values[current_state] = self.mdp.calculate_expected_value(
                    current_state, selected_action, previous_values
                )
            
            maximum_delta = max(abs(current_state_values[s] - previous_values[s]) 
                              for s in current_state_values)
            
            if maximum_delta < convergence_threshold:
                break
                
            evaluation_iteration += 1
            
        return current_state_values
        
    def improve_policy(self, current_state_values):
        """Policy improvement step"""
        improved_policy = {}
        
        for current_state in [self.mdp.HILL_TOP_STATE, self.mdp.ROLLING_DOWN_STATE,
                             self.mdp.HILL_BOTTOM_STATE]:
            best_action = None
            best_value = -float('inf')
            
            for action_choice in [self.mdp.DRIVE_ACTION, self.mdp.NO_DRIVE_ACTION]:
                expected_value = self.mdp.calculate_expected_value(
                    current_state, action_choice, current_state_values
                )
                
                if expected_value > best_value:
                    best_value = expected_value
                    best_action = action_choice
                    
            improved_policy[current_state] = best_action
            
        return improved_policy
        
    def execute_policy_iteration(self):
        """Perform policy iteration algorithm"""
        print("\n" + "="*70)
        print("POLICY ITERATION ALGORITHM")
        print("="*70)
        
        # Start with policy that never drives
        current_policy = {
            self.mdp.HILL_TOP_STATE: self.mdp.NO_DRIVE_ACTION,
            self.mdp.ROLLING_DOWN_STATE: self.mdp.NO_DRIVE_ACTION,
            self.mdp.HILL_BOTTOM_STATE: self.mdp.NO_DRIVE_ACTION
        }
        
        iteration_count = 0
        
        while True:
            print(f"\n{'='*70}")
            print(f"Policy Iteration - Round {iteration_count}")
            print(f"{'='*70}")
            
            # Display current policy
            print("\nCurrent Policy:")
            for state_id, state_name in self.mdp.state_descriptions.items():
                action_name = self.mdp.action_descriptions[current_policy[state_id]]
                print(f"  π({state_name}) = {action_name}")
            
            # Policy evaluation
            state_values = self.evaluate_current_policy(current_policy)
            
            print("\nState Values under Current Policy:")
            for state_id, state_name in self.mdp.state_descriptions.items():
                print(f"  V({state_name}) = {state_values[state_id]:.6f}")
            
            # Store history
            self.policy_evolution_history.append(current_policy.copy())
            self.value_evolution_history.append(state_values.copy())
            
            # Policy improvement
            improved_policy = self.improve_policy(state_values)
            
            # Check for convergence
            if improved_policy == current_policy:
                print("\n" + "="*70)
                print("POLICY HAS CONVERGED!")
                print("="*70)
                break
                
            current_policy = improved_policy
            iteration_count += 1
        
        print("\n" + "="*70)
        print("FINAL POLICY ITERATION RESULTS")
        print("="*70)
        print("\nOptimal Policy:")
        for state_id, state_name in self.mdp.state_descriptions.items():
            action_name = self.mdp.action_descriptions[current_policy[state_id]]
            print(f"  π*({state_name}) = {action_name}")
            
        print("\nOptimal State Values:")
        for state_id, state_name in self.mdp.state_descriptions.items():
            print(f"  V*({state_name}) = {state_values[state_id]:.6f}")
        
        return current_policy, state_values


def main():
    """Main execution function"""
    print("\n" + "="*70)
    print("MARS ROVER MDP ANALYSIS")
    print("="*70)
    
    # Initialize MDP
    rover_mdp = MarsRoverMDP()
    
    # Task i: Draw MDP graphically
    print("\nTask i: Creating MDP Visualization...")
    rover_mdp.visualize_mdp_graph()
    
    # Task ii: Value Iteration
    print("\nTask ii: Solving with Value Iteration...")
    value_iteration_solver = ValueIterationSolver(rover_mdp)
    optimal_values_vi, optimal_policy_vi = value_iteration_solver.execute_value_iteration(
        maximum_iterations=60
    )
    
    # Task iii: Policy Iteration
    print("\nTask iii: Solving with Policy Iteration...")
    policy_iteration_solver = PolicyIterationSolver(rover_mdp)
    optimal_policy_pi, optimal_values_pi = policy_iteration_solver.execute_policy_iteration()
    
    
if __name__ == "__main__":
    main()