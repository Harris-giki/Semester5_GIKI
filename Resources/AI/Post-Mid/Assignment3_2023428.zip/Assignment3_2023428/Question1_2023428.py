import numpy as np
import time
from typing import Tuple, List, Optional

class ConnectFourGame:
    def __init__(self, total_rows=6, total_columns=7):
        self.total_rows = total_rows
        self.total_columns = total_columns
        self.game_board = np.zeros((total_rows, total_columns), dtype=int)
        self.EMPTY_CELL = 0
        self.PLAYER_PIECE = 1
        self.AI_PIECE = 2
        self.WINNING_LENGTH = 4
        
    def create_fresh_board(self):
        """Initialize empty game board"""
        self.game_board = np.zeros((self.total_rows, self.total_columns), dtype=int)
        
    def place_game_piece(self, row_position, column_position, player_marker):
        """Place a piece on the board at specified position"""
        self.game_board[row_position][column_position] = player_marker
        
    def check_column_availability(self, column_position):
        """Check if a column has space for a new piece"""
        return self.game_board[self.total_rows - 1][column_position] == self.EMPTY_CELL
        
    def find_next_available_row(self, column_position):
        """Find the lowest empty row in a column"""
        for row_index in range(self.total_rows):
            if self.game_board[row_index][column_position] == self.EMPTY_CELL:
                return row_index
        return None
        
    def display_board_state(self):
        """Print the current board state"""
        print("\nCurrent Board State:")
        print(np.flip(self.game_board, 0))
        print("Column numbers: 0  1  2  3  4  5  6\n")
        
    def check_victory_condition(self, player_marker):
        """Check if the specified player has won"""
        # Check horizontal sequences
        for row_idx in range(self.total_rows):
            for col_idx in range(self.total_columns - 3):
                if (self.game_board[row_idx][col_idx] == player_marker and
                    self.game_board[row_idx][col_idx + 1] == player_marker and
                    self.game_board[row_idx][col_idx + 2] == player_marker and
                    self.game_board[row_idx][col_idx + 3] == player_marker):
                    return True
                    
        # Check vertical sequences
        for col_idx in range(self.total_columns):
            for row_idx in range(self.total_rows - 3):
                if (self.game_board[row_idx][col_idx] == player_marker and
                    self.game_board[row_idx + 1][col_idx] == player_marker and
                    self.game_board[row_idx + 2][col_idx] == player_marker and
                    self.game_board[row_idx + 3][col_idx] == player_marker):
                    return True
                    
        # Check positive diagonal sequences
        for row_idx in range(self.total_rows - 3):
            for col_idx in range(self.total_columns - 3):
                if (self.game_board[row_idx][col_idx] == player_marker and
                    self.game_board[row_idx + 1][col_idx + 1] == player_marker and
                    self.game_board[row_idx + 2][col_idx + 2] == player_marker and
                    self.game_board[row_idx + 3][col_idx + 3] == player_marker):
                    return True
                    
        # Check negative diagonal sequences
        for row_idx in range(3, self.total_rows):
            for col_idx in range(self.total_columns - 3):
                if (self.game_board[row_idx][col_idx] == player_marker and
                    self.game_board[row_idx - 1][col_idx + 1] == player_marker and
                    self.game_board[row_idx - 2][col_idx + 2] == player_marker and
                    self.game_board[row_idx - 3][col_idx + 3] == player_marker):
                    return True
        return False
        
    def get_valid_column_positions(self):
        """Return list of columns that can accept new pieces"""
        available_columns = []
        for col_idx in range(self.total_columns):
            if self.check_column_availability(col_idx):
                available_columns.append(col_idx)
        return available_columns
        
    def calculate_board_score(self, player_marker):
        """Evaluation function to score the current board state"""
        total_score = 0
        
        # Score center column (strategic position)
        center_column_index = self.total_columns // 2
        center_column_pieces = [int(cell) for cell in list(self.game_board[:, center_column_index])]
        center_piece_count = center_column_pieces.count(player_marker)
        total_score += center_piece_count * 3
        
        # Score horizontal sequences
        for row_idx in range(self.total_rows):
            row_sequence = [int(cell) for cell in list(self.game_board[row_idx, :])]
            for col_idx in range(self.total_columns - 3):
                window_segment = row_sequence[col_idx:col_idx + self.WINNING_LENGTH]
                total_score += self.evaluate_window_segment(window_segment, player_marker)
                
        # Score vertical sequences
        for col_idx in range(self.total_columns):
            column_sequence = [int(cell) for cell in list(self.game_board[:, col_idx])]
            for row_idx in range(self.total_rows - 3):
                window_segment = column_sequence[row_idx:row_idx + self.WINNING_LENGTH]
                total_score += self.evaluate_window_segment(window_segment, player_marker)
                
        # Score positive diagonal sequences
        for row_idx in range(self.total_rows - 3):
            for col_idx in range(self.total_columns - 3):
                window_segment = [self.game_board[row_idx + offset][col_idx + offset] for offset in range(self.WINNING_LENGTH)]
                total_score += self.evaluate_window_segment(window_segment, player_marker)
                
        # Score negative diagonal sequences
        for row_idx in range(self.total_rows - 3):
            for col_idx in range(self.total_columns - 3):
                window_segment = [self.game_board[row_idx + 3 - offset][col_idx + offset] for offset in range(self.WINNING_LENGTH)]
                total_score += self.evaluate_window_segment(window_segment, player_marker)
                
        return total_score
        
    def evaluate_window_segment(self, window_segment, player_marker):
        """Evaluate a window of 4 positions"""
        evaluation_score = 0
        opponent_marker = self.PLAYER_PIECE if player_marker == self.AI_PIECE else self.AI_PIECE
        
        player_piece_count = window_segment.count(player_marker)
        empty_space_count = window_segment.count(self.EMPTY_CELL)
        opponent_piece_count = window_segment.count(opponent_marker)
        
        if player_piece_count == 4:
            evaluation_score += 100
        elif player_piece_count == 3 and empty_space_count == 1:
            evaluation_score += 5
        elif player_piece_count == 2 and empty_space_count == 2:
            evaluation_score += 2
            
        if opponent_piece_count == 3 and empty_space_count == 1:
            evaluation_score -= 4
            
        return evaluation_score
        
    def check_terminal_state(self):
        """Check if game has ended"""
        return (self.check_victory_condition(self.PLAYER_PIECE) or 
                self.check_victory_condition(self.AI_PIECE) or 
                len(self.get_valid_column_positions()) == 0)


class MinimaxAI:
    def __init__(self, game_instance: ConnectFourGame):
        self.game = game_instance
        self.nodes_explored_count = 0
        
    def execute_minimax_algorithm(self, board_state, depth_limit, alpha_value, beta_value, 
                                   is_maximizing_player):
        """Minimax algorithm with alpha-beta pruning"""
        self.nodes_explored_count += 1
        available_moves = self.game.get_valid_column_positions()
        is_terminal_node = self.game.check_terminal_state()
        
        if depth_limit == 0 or is_terminal_node:
            if is_terminal_node:
                if self.game.check_victory_condition(self.game.AI_PIECE):
                    return (None, 10000000)
                elif self.game.check_victory_condition(self.game.PLAYER_PIECE):
                    return (None, -10000000)
                else:
                    return (None, 0)
            else:
                return (None, self.game.calculate_board_score(self.game.AI_PIECE))
                
        if is_maximizing_player:
            best_score_value = -np.inf
            optimal_column = np.random.choice(available_moves)
            
            for column_choice in available_moves:
                target_row = self.game.find_next_available_row(column_choice)
                temporary_board = self.game.game_board.copy()
                self.game.place_game_piece(target_row, column_choice, self.game.AI_PIECE)
                
                updated_score = self.execute_minimax_algorithm(self.game.game_board, depth_limit - 1, 
                                                               alpha_value, beta_value, False)[1]
                self.game.game_board = temporary_board
                
                if updated_score > best_score_value:
                    best_score_value = updated_score
                    optimal_column = column_choice
                    
                alpha_value = max(alpha_value, best_score_value)
                if alpha_value >= beta_value:
                    break
                    
            return optimal_column, best_score_value
            
        else:
            best_score_value = np.inf
            optimal_column = np.random.choice(available_moves)
            
            for column_choice in available_moves:
                target_row = self.game.find_next_available_row(column_choice)
                temporary_board = self.game.game_board.copy()
                self.game.place_game_piece(target_row, column_choice, self.game.PLAYER_PIECE)
                
                updated_score = self.execute_minimax_algorithm(self.game.game_board, depth_limit - 1,
                                                               alpha_value, beta_value, True)[1]
                self.game.game_board = temporary_board
                
                if updated_score < best_score_value:
                    best_score_value = updated_score
                    optimal_column = column_choice
                    
                beta_value = min(beta_value, best_score_value)
                if alpha_value >= beta_value:
                    break
                    
            return optimal_column, best_score_value
            
    def determine_best_move(self, search_depth=4):
        """Find the best move for AI"""
        self.nodes_explored_count = 0
        optimal_column, minimax_score = self.execute_minimax_algorithm(
            self.game.game_board, search_depth, -np.inf, np.inf, True
        )
        return optimal_column


def simulate_game_session(opponent_type='human', total_games=1):
    """Main game loop"""
    game_outcomes_record = {'AI Wins': 0, 'Player Wins': 0, 'Draws': 0}
    total_nodes_expanded = []
    execution_times_list = []
    
    for game_number in range(total_games):
        print(f"\n{'='*50}")
        print(f"Starting Game {game_number + 1}")
        print(f"{'='*50}")
        
        game_instance = ConnectFourGame()
        ai_player = MinimaxAI(game_instance)
        game_instance.create_fresh_board()
        game_finished = False
        current_turn = 0
        
        while not game_finished:
            game_instance.display_board_state()
            
            if current_turn == 0:  # Human or Random Player
                if opponent_type == 'human':
                    selected_column = int(input("Your turn! Select column (0-6): "))
                    while not game_instance.check_column_availability(selected_column):
                        selected_column = int(input("Column full! Choose another (0-6): "))
                else:  # Random player
                    available_positions = game_instance.get_valid_column_positions()
                    selected_column = np.random.choice(available_positions)
                    print(f"Random player chooses column: {selected_column}")
                    
                target_row = game_instance.find_next_available_row(selected_column)
                game_instance.place_game_piece(target_row, selected_column, game_instance.PLAYER_PIECE)
                
                if game_instance.check_victory_condition(game_instance.PLAYER_PIECE):
                    game_instance.display_board_state()
                    print("Player wins!")
                    game_outcomes_record['Player Wins'] += 1
                    game_finished = True
                    
            else:  # AI Player
                print("AI is calculating optimal move...")
                move_start_time = time.time()
                selected_column = ai_player.determine_best_move(search_depth=4)
                move_duration = time.time() - move_start_time
                
                execution_times_list.append(move_duration)
                total_nodes_expanded.append(ai_player.nodes_explored_count)
                
                print(f"AI chooses column: {selected_column}")
                print(f"Nodes expanded: {ai_player.nodes_explored_count}")
                print(f"Computation time: {move_duration:.4f} seconds")
                
                if selected_column is not None:
                    target_row = game_instance.find_next_available_row(selected_column)
                    game_instance.place_game_piece(target_row, selected_column, game_instance.AI_PIECE)
                    
                    if game_instance.check_victory_condition(game_instance.AI_PIECE):
                        game_instance.display_board_state()
                        print("AI wins!")
                        game_outcomes_record['AI Wins'] += 1
                        game_finished = True
                        
            if len(game_instance.get_valid_column_positions()) == 0 and not game_finished:
                game_instance.display_board_state()
                print("Draw! Board is full.")
                game_outcomes_record['Draws'] += 1
                game_finished = True
                
            current_turn = (current_turn + 1) % 2
            
    # Display comprehensive statistics
    print("\n" + "="*50)
    print("GAME STATISTICS SUMMARY")
    print("="*50)
    print(f"\nTotal Games Played: {total_games}")
    print(f"AI Victories: {game_outcomes_record['AI Wins']}")
    print(f"Player Victories: {game_outcomes_record['Player Wins']}")
    print(f"Draw Games: {game_outcomes_record['Draws']}")
    
    if total_nodes_expanded:
        print(f"\nAverage Nodes Expanded per Move: {np.mean(total_nodes_expanded):.2f}")
        print(f"Total Nodes Expanded: {sum(total_nodes_expanded)}")
        print(f"Maximum Nodes in Single Move: {max(total_nodes_expanded)}")
        print(f"Minimum Nodes in Single Move: {min(total_nodes_expanded)}")
        
    if execution_times_list:
        print(f"\nAverage Runtime per Move: {np.mean(execution_times_list):.4f} seconds")
        print(f"Maximum Runtime: {max(execution_times_list):.4f} seconds")
        print(f"Minimum Runtime: {min(execution_times_list):.4f} seconds")
    
    return game_outcomes_record, total_nodes_expanded, execution_times_list


if __name__ == "__main__":
    print("Connect Four - AI vs Player")
    print("1. Play against AI (Human)")
    print("2. Watch AI vs Random Player (Multiple Games)")
    
    game_mode = input("\nSelect mode (1 or 2): ")
    
    if game_mode == '1':
        simulate_game_session(opponent_type='human', total_games=1)
    else:
        number_of_games = int(input("Enter number of games to simulate: "))
        simulate_game_session(opponent_type='random', total_games=number_of_games)