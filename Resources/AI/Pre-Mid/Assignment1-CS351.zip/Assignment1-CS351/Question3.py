import time
from collections import deque

# Board setup - 0 is empty, 1 is X, -1 is O
def make_board():
    return [[0, 0, 0], [0, 0, 0], [0, 0, 0]]

def show_board(board):
    marks = {0: '.', 1: 'X', -1: 'O'}
    for row in board:
        print(' '.join(marks[cell] for cell in row))
    print()

def check_winner(board):
    # rows and columns
    for i in range(3):
        if abs(sum(board[i])) == 3:
            return board[i][0]
        if abs(sum(board[j][i] for j in range(3))) == 3:
            return board[0][i]
    
    # diagonals
    if abs(board[0][0] + board[1][1] + board[2][2]) == 3:
        return board[1][1]
    if abs(board[0][2] + board[1][1] + board[2][0]) == 3:
        return board[1][1]
    
    return 0

def is_full(board):
    return all(board[i][j] != 0 for i in range(3) for j in range(3))

def get_moves(board, turn):
    moves = []
    for i in range(3):
        for j in range(3):
            if board[i][j] == 0:
                # make a copy and place the mark
                new_board = [row[:] for row in board]
                new_board[i][j] = turn
                moves.append(new_board)
    return moves

def bfs_search(start_board, turn):
    q = deque([(start_board, turn, 0)])
    explored = 0
    wins = {1: 0, -1: 0, 0: 0}  # X wins, O wins, draws
    
    while q:
        board, current_turn, depth = q.popleft()
        explored += 1
        
        winner = check_winner(board)
        if winner != 0:
            wins[winner] += 1
            continue
        
        if is_full(board):
            wins[0] += 1
            continue
        
        # get next possible states
        next_moves = get_moves(board, current_turn)
        for move in next_moves:
            q.append((move, -current_turn, depth + 1))
    
    return explored, wins

def dfs_search(start_board, turn):
    stack = [(start_board, turn, 0)]
    explored = 0
    wins = {1: 0, -1: 0, 0: 0}
    
    while stack:
        board, current_turn, depth = stack.pop()
        explored += 1
        
        winner = check_winner(board)
        if winner != 0:
            wins[winner] += 1
            continue
        
        if is_full(board):
            wins[0] += 1
            continue
        
        next_moves = get_moves(board, current_turn)
        for move in next_moves:
            stack.append((move, -current_turn, depth + 1))
    
    return explored, wins

def ids_search(start_board, turn, max_depth=9):
    explored = 0
    wins = {1: 0, -1: 0, 0: 0}
    
    for limit in range(max_depth + 1):
        stack = [(start_board, turn, 0)]
        
        while stack:
            board, current_turn, depth = stack.pop()
            explored += 1
            
            winner = check_winner(board)
            if winner != 0:
                wins[winner] += 1
                continue
            
            if is_full(board):
                wins[0] += 1
                continue
            
            # only expand if under depth limit
            if depth < limit:
                next_moves = get_moves(board, current_turn)
                for move in next_moves:
                    stack.append((move, -current_turn, depth + 1))
    
    return explored, wins

def find_best_move(board, turn):
    # simple minimax to get optimal play
    best_score = float('-inf') if turn == 1 else float('inf')
    best = None
    
    for i in range(3):
        for j in range(3):
            if board[i][j] == 0:
                board[i][j] = turn
                score = minimax(board, -turn, False if turn == 1 else True)
                board[i][j] = 0
                
                if turn == 1 and score > best_score:
                    best_score = score
                    best = (i, j)
                elif turn == -1 and score < best_score:
                    best_score = score
                    best = (i, j)
    
    return best, best_score

def minimax(board, turn, maximizing):
    winner = check_winner(board)
    if winner == 1:
        return 1
    if winner == -1:
        return -1
    if is_full(board):
        return 0
    
    if maximizing:
        max_score = float('-inf')
        for i in range(3):
            for j in range(3):
                if board[i][j] == 0:
                    board[i][j] = turn
                    score = minimax(board, -turn, False)
                    board[i][j] = 0
                    max_score = max(max_score, score)
        return max_score
    else:
        min_score = float('inf')
        for i in range(3):
            for j in range(3):
                if board[i][j] == 0:
                    board[i][j] = turn
                    score = minimax(board, -turn, True)
                    board[i][j] = 0
                    min_score = min(min_score, score)
        return min_score

def run_tests():
    print("=== TIC-TAC-TOE GAME TREE ANALYSIS ===\n")
    
    # Test 1: empty board
    print("Test 1: Empty Board")
    board1 = make_board()
    show_board(board1)
    
    start = time.time()
    states_bfs, outcomes_bfs = bfs_search(board1, 1)
    time_bfs = time.time() - start
    
    start = time.time()
    states_dfs, outcomes_dfs = dfs_search(board1, 1)
    time_dfs = time.time() - start
    
    start = time.time()
    states_ids, outcomes_ids = ids_search(board1, 1)
    time_ids = time.time() - start
    
    print(f"BFS: {states_bfs} states, {time_bfs:.4f}s | X:{outcomes_bfs[1]} O:{outcomes_bfs[-1]} Draw:{outcomes_bfs[0]}")
    print(f"DFS: {states_dfs} states, {time_dfs:.4f}s | X:{outcomes_dfs[1]} O:{outcomes_dfs[-1]} Draw:{outcomes_dfs[0]}")
    print(f"IDS: {states_ids} states, {time_ids:.4f}s | X:{outcomes_ids[1]} O:{outcomes_ids[-1]} Draw:{outcomes_ids[0]}")
    
    move, score = find_best_move(board1, 1)
    print(f"Best opening for X: position ({move[0]}, {move[1]}), score: {score}\n")
    
    # Test 2: partially filled
    print("Test 2: Mid-game Position")
    board2 = [[1, 0, -1], [0, 1, 0], [0, 0, 0]]
    show_board(board2)
    
    start = time.time()
    states_bfs, outcomes_bfs = bfs_search(board2, -1)
    time_bfs = time.time() - start
    
    start = time.time()
    states_dfs, outcomes_dfs = dfs_search(board2, -1)
    time_dfs = time.time() - start
    
    start = time.time()
    states_ids, outcomes_ids = ids_search(board2, -1)
    time_ids = time.time() - start
    
    print(f"BFS: {states_bfs} states, {time_bfs:.4f}s | X:{outcomes_bfs[1]} O:{outcomes_bfs[-1]} Draw:{outcomes_bfs[0]}")
    print(f"DFS: {states_dfs} states, {time_dfs:.4f}s | X:{outcomes_dfs[1]} O:{outcomes_dfs[-1]} Draw:{outcomes_dfs[0]}")
    print(f"IDS: {states_ids} states, {time_ids:.4f}s | X:{outcomes_ids[1]} O:{outcomes_ids[-1]} Draw:{outcomes_ids[0]}")
    
    move, score = find_best_move(board2, -1)
    print(f"Best move for O: position ({move[0]}, {move[1]}), score: {score}\n")
    
    # Test 3: almost done
    print("Test 3: Near-end Position")
    board3 = [[1, -1, 1], [-1, 1, -1], [0, 0, 1]]
    show_board(board3)
    
    start = time.time()
    states_bfs, outcomes_bfs = bfs_search(board3, -1)
    time_bfs = time.time() - start
    
    start = time.time()
    states_dfs, outcomes_dfs = dfs_search(board3, -1)
    time_dfs = time.time() - start
    
    start = time.time()
    states_ids, outcomes_ids = ids_search(board3, -1)
    time_ids = time.time() - start
    
    print(f"BFS: {states_bfs} states, {time_bfs:.4f}s | X:{outcomes_bfs[1]} O:{outcomes_bfs[-1]} Draw:{outcomes_bfs[0]}")
    print(f"DFS: {states_dfs} states, {time_dfs:.4f}s | X:{outcomes_dfs[1]} O:{outcomes_dfs[-1]} Draw:{outcomes_dfs[0]}")
    print(f"IDS: {states_ids} states, {time_ids:.4f}s | X:{outcomes_ids[1]} O:{outcomes_ids[-1]} Draw:{outcomes_ids[0]}")
    
    move, score = find_best_move(board3, -1)
    print(f"Best move for O: position ({move[0]}, {move[1]}), score: {score}\n")
    
    # Test 4: X about to win
    print("Test 4: Critical Defense Scenario")
    board4 = [[1, 1, 0], [-1, -1, 0], [0, 0, 0]]
    show_board(board4)
    
    start = time.time()
    states_bfs, outcomes_bfs = bfs_search(board4, 1)
    time_bfs = time.time() - start
    
    start = time.time()
    states_dfs, outcomes_dfs = dfs_search(board4, 1)
    time_dfs = time.time() - start
    
    start = time.time()
    states_ids, outcomes_ids = ids_search(board4, 1)
    time_ids = time.time() - start
    
    print(f"BFS: {states_bfs} states, {time_bfs:.4f}s | X:{outcomes_bfs[1]} O:{outcomes_bfs[-1]} Draw:{outcomes_bfs[0]}")
    print(f"DFS: {states_dfs} states, {time_dfs:.4f}s | X:{outcomes_dfs[1]} O:{outcomes_dfs[-1]} Draw:{outcomes_dfs[0]}")
    print(f"IDS: {states_ids} states, {time_ids:.4f}s | X:{outcomes_ids[1]} O:{outcomes_ids[-1]} Draw:{outcomes_ids[0]}")
    
    winner = check_winner(board4)
    if winner:
        print(f"Game over! Winner: {'X' if winner == 1 else 'O'}")
    else:
        move, score = find_best_move(board4, 1)
        print(f"Best move for X: position ({move[0]}, {move[1]}), score: {score}")

if __name__ == "__main__":
    run_tests()