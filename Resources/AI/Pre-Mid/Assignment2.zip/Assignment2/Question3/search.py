import heapq

def Astar(root):
    """A* that works as BFS when h=0: allows same-g re-exploration."""
    open_set = []
    counter = 0
    heapq.heappush(open_set, (root.f, counter, root))
    counter += 1

    came_from = {}
    g_score = {root.state: root.g}
    in_open = {root.state}  # track states in open set

    while open_set:
        _, _, current = heapq.heappop(open_set)

        # Remove from open set
        in_open.discard(current.state)

        if current.is_goal():
            # Reconstruct path
            path = []
            node = current
            while node:
                path.append(node)
                node = came_from.get(node.state)
            return list(reversed(path))

        for child in current.generate_children():
            child_state = child.state
            tentative_g = child.g

            # Allow re-exploration if BETTER or SAME g (BFS behavior)
            if (child_state not in g_score or 
                tentative_g < g_score[child_state] or
                (tentative_g == g_score[child_state] and child_state not in in_open)):

                came_from[child_state] = current
                g_score[child_state] = tentative_g
                f = tentative_g + child.evaluate_heuristic()
                heapq.heappush(open_set, (f, counter, child))
                in_open.add(child_state)
                counter += 1

    return None