from node import Node
import copy


class FifteensNode(Node):
    """Extends the Node class to solve the 15 puzzle."""

    def __init__(self, parent=None, g=0, board=None, input_str=None):
        if input_str:
            self.board = []
            for i, line in enumerate(filter(None, input_str.splitlines())):
                self.board.append([int(n) for n in line.split()])
        else:
            self.board = board
        super(FifteensNode, self).__init__(parent, g)

    def generate_children(self):
        """Generates children by moving the empty cell (0) up, down, left, right."""
        children = []
        board = self.board
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]  # up, down, left, right

        # Find position of empty cell (0)
        empty_i, empty_j = None, None
        for i in range(4):
            for j in range(4):
                if board[i][j] == 0:
                    empty_i, empty_j = i, j
                    break
            if empty_i is not None:
                break

        for di, dj in directions:
            new_i, new_j = empty_i + di, empty_j + dj
            if 0 <= new_i < 4 and 0 <= new_j < 4:
                # Deep copy the board
                new_board = copy.deepcopy(board)
                # Swap empty cell with adjacent tile
                new_board[empty_i][empty_j] = new_board[new_i][new_j]
                new_board[new_i][new_j] = 0

                # Create child node: g increases by 1
                child = FifteensNode(parent=self, g=self.g + 1, board=new_board)
                children.append(child)

        return children

    def is_goal(self):
        """Check if current board is the goal state: 1 to 15 in order, 0 at bottom-right."""
        goal = [
            [1, 2, 3, 4],
            [5, 6, 7, 8],
            [9, 10, 11, 12],
            [13, 14, 15, 0]
        ]
        return self.board == goal

    def evaluate_heuristic(self):
        """Manhattan distance heuristic: sum of distances of each tile from its goal position."""
        total = 0
        for i in range(4):
            for j in range(4):
                if self.board[i][j] == 0:
                    continue
                value = self.board[i][j]
                # Goal position of value (1-based index)
                goal_i = (value - 1) // 4
                goal_j = (value - 1) % 4
                total += abs(i - goal_i) + abs(j - goal_j)
        return total

    def _get_state(self):
        return tuple([n for row in self.board for n in row])

    def __str__(self):
        sb = []
        for row in self.board:
            for i in row:
                sb.append(' ')
                if i == 0:
                    sb.append('  ')
                else:
                    if i < 10:
                        sb.append(' ')
                    sb.append(str(i))
            sb.append('\n')
        return ''.join(sb)

class SuperqueensNode(Node):
    def __init__(self, parent=None, g=0, queen_positions=[], n=1):
        self.queen_positions = queen_positions
        self.n = n
        super(SuperqueensNode, self).__init__(parent, g)

    def generate_children(self):
        children = []
        row = len(self.queen_positions)
        if row >= self.n:
            return children

        for col in range(self.n):
            safe = True
            for r, c in self.queen_positions:
                dr = abs(r - row)
                dc = abs(c - col)
                if (r == row or c == col or dr == dc or
                    (dr == 1 and dc == 2) or (dr == 2 and dc == 1)):
                    safe = False
                    break
            if safe:
                new_pos = self.queen_positions + [(row, col)]
                child = SuperqueensNode(
                    parent=self,
                    g=self.g + 1,
                    queen_positions=new_pos,
                    n=self.n
                )
                children.append(child)
        return children

    def is_goal(self):
        return len(self.queen_positions) == self.n

    def evaluate_heuristic(self):
        # Optional: could estimate remaining conflicts, but not needed
        return 0

    def _get_state(self):
        return tuple(self.queen_positions)

    def __str__(self):
        sb = [[' . '] * self.n for _ in range(self.n)]
        for i, j in self.queen_positions:
            sb[i][j] = ' Q '
        return '\n'.join([''.join(row) for row in sb])