import time
import sys
import os

def read_sudoku_from_file(input_filename):
    """Reads the Sudoku board from a file and returns (size, board)."""
    path = os.path.join(os.path.dirname(__file__), input_filename)
    with open(path, 'r', encoding='utf-8') as file:
        lines = [line.strip() for line in file.readlines() if line.strip()]
    if not lines:
        raise ValueError("Input file is empty or not properly formatted.")

    size = int(lines[0])
    board = [list(map(int, line.split())) for line in lines[1:]]
    return size, board


def print_board(board):
    """Displays the Sudoku board."""
    for row in board:
        print(" ".join(str(num) for num in row))
    print()


def find_empty_cell(board):
    """Finds the next empty cell in the board (represented by 0)."""
    for i in range(len(board)):
        for j in range(len(board[i])):
            if board[i][j] == 0:
                return i, j  # row, column
    return None


def is_valid_move(board, row, col, num):
    """Checks if placing 'num' in board[row][col] is valid."""
    size = len(board)
    subgrid_size = int(size ** 0.5)

    # Check row and column
    if num in board[row] or num in [board[i][col] for i in range(size)]:
        return False

    # Check subgrid
    start_row = (row // subgrid_size) * subgrid_size
    start_col = (col // subgrid_size) * subgrid_size
    for i in range(subgrid_size):
        for j in range(subgrid_size):
            if board[start_row + i][start_col + j] == num:
                return False

    return True


def solve_sudoku_backtracking(board):
    """Solves the Sudoku puzzle using backtracking."""
    empty = find_empty_cell(board)
    if not empty:
        return True  # Solved

    row, col = empty
    size = len(board)

    for num in range(1, size + 1):
        if is_valid_move(board, row, col, num):
            board[row][col] = num
            if solve_sudoku_backtracking(board):
                return True
            board[row][col] = 0  # Backtrack

    return False


def write_solution_to_file(output_filename, board, solution_found):
    """Writes the Sudoku solution or 'no solution' message to a file."""
    with open(output_filename, 'w', encoding='utf-8') as file:
        if solution_found:
            for row in board:
                file.write(" ".join(str(num) for num in row) + "\n")
        else:
            file.write("No solution exists.\n")


def main():
    input_filename = "sudoku_input.txt"  # change if your file name differs

    try:
        size, board = read_sudoku_from_file(input_filename)
    except FileNotFoundError:
        print(f"Error: File '{input_filename}' not found.")
        sys.exit(1)

    print(f"Input Sudoku ({size}x{size}):")
    print_board(board)

    start_time = time.time()
    solved = solve_sudoku_backtracking(board)
    end_time = time.time()

    runtime = end_time - start_time
    print("Solved Sudoku:" if solved else "No solution exists.")
    print_board(board)

    print(f"⏱ Runtime: {runtime:.4f} seconds for {size}x{size} Sudoku")

    # Write output file
    output_filename = input_filename.replace(".txt", "Solution.txt")
    write_solution_to_file(output_filename, board, solved)
    print(f"Solution written to '{output_filename}'")


if __name__ == "__main__":
    main()
