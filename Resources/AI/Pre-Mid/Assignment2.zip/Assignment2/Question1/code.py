import math
import random
import time

# ----------------------------
# GAME CONFIGURATION
# ----------------------------
ROWS = 6
COLUMNS = 7
PLAYER_AI = 1
PLAYER_RANDOM = 2
EMPTY_SLOT = 0
SEARCH_DEPTH = 4  # You can increase depth for stronger AI but it will take longer

# ----------------------------
# GAME BOARD FUNCTIONS
# ----------------------------
def create_game_board():
    """Create a 6x7 Connect Four board filled with 0s."""
    return [[EMPTY_SLOT for _ in range(COLUMNS)] for _ in range(ROWS)]

def drop_disc(board, row, col, player):
    board[row][col] = player

def is_valid_move(board, col):
    return board[0][col] == EMPTY_SLOT

def get_next_open_row(board, col):
    for r in range(ROWS - 1, -1, -1):
        if board[r][col] == EMPTY_SLOT:
            return r

def print_board(board):
    """Display board (flipped vertically for intuitive view)."""
    print("\nCurrent Board:")
    for row in board:
        print(row)
    print()

def get_valid_moves(board):
    return [c for c in range(COLUMNS) if is_valid_move(board, c)]

def check_winner(board, player):
    """Return True if the given player has won."""
    # Horizontal
    for c in range(COLUMNS - 3):
        for r in range(ROWS):
            if all(board[r][c+i] == player for i in range(4)):
                return True
    # Vertical
    for c in range(COLUMNS):
        for r in range(ROWS - 3):
            if all(board[r+i][c] == player for i in range(4)):
                return True
    # Positive Diagonal
    for c in range(COLUMNS - 3):
        for r in range(ROWS - 3):
            if all(board[r+i][c+i] == player for i in range(4)):
                return True
    # Negative Diagonal
    for c in range(COLUMNS - 3):
        for r in range(3, ROWS):
            if all(board[r-i][c+i] == player for i in range(4)):
                return True
    return False

def is_board_full(board):
    return all(board[0][c] != EMPTY_SLOT for c in range(COLUMNS))

# ----------------------------
# EVALUATION FUNCTION
# ----------------------------
def score_window(window, player):
    """Score a 4-cell window for heuristic evaluation."""
    score = 0
    opponent = PLAYER_RANDOM if player == PLAYER_AI else PLAYER_AI

    if window.count(player) == 4:
        score += 100
    elif window.count(player) == 3 and window.count(EMPTY_SLOT) == 1:
        score += 10
    elif window.count(player) == 2 and window.count(EMPTY_SLOT) == 2:
        score += 5

    if window.count(opponent) == 3 and window.count(EMPTY_SLOT) == 1:
        score -= 8

    return score

def evaluate_board(board, player):
    """Return an overall heuristic score of the board."""
    score = 0

    # Center column preference (helps AI pick central positions)
    center_column = [board[r][COLUMNS//2] for r in range(ROWS)]
    center_count = center_column.count(player)
    score += center_count * 6

    # Horizontal
    for r in range(ROWS):
        row_array = [board[r][c] for c in range(COLUMNS)]
        for c in range(COLUMNS - 3):
            score += score_window(row_array[c:c+4], player)

    # Vertical
    for c in range(COLUMNS):
        col_array = [board[r][c] for r in range(ROWS)]
        for r in range(ROWS - 3):
            score += score_window(col_array[r:r+4], player)

    # Diagonals
    for r in range(ROWS - 3):
        for c in range(COLUMNS - 3):
            diag1 = [board[r+i][c+i] for i in range(4)]
            diag2 = [board[r+3-i][c+i] for i in range(4)]
            score += score_window(diag1, player)
            score += score_window(diag2, player)

    return score

# ----------------------------
# MINIMAX WITH ALPHA-BETA PRUNING
# ----------------------------
def minimax(board, depth, alpha, beta, maximizing_player, node_counter):
    valid_moves = get_valid_moves(board)
    is_terminal = check_winner(board, PLAYER_AI) or check_winner(board, PLAYER_RANDOM) or is_board_full(board)
    node_counter[0] += 1  # Count expanded node

    if depth == 0 or is_terminal:
        if check_winner(board, PLAYER_AI):
            return (None, 10**6)
        elif check_winner(board, PLAYER_RANDOM):
            return (None, -10**6)
        else:
            return (None, evaluate_board(board, PLAYER_AI))

    if maximizing_player:
        value = -math.inf
        best_col = random.choice(valid_moves)
        for col in valid_moves:
            row = get_next_open_row(board, col)
            temp_board = [r[:] for r in board]
            drop_disc(temp_board, row, col, PLAYER_AI)
            new_score = minimax(temp_board, depth - 1, alpha, beta, False, node_counter)[1]
            if new_score > value:
                value = new_score
                best_col = col
            alpha = max(alpha, value)
            if alpha >= beta:
                break
        return best_col, value

    else:
        value = math.inf
        best_col = random.choice(valid_moves)
        for col in valid_moves:
            row = get_next_open_row(board, col)
            temp_board = [r[:] for r in board]
            drop_disc(temp_board, row, col, PLAYER_RANDOM)
            new_score = minimax(temp_board, depth - 1, alpha, beta, True, node_counter)[1]
            if new_score < value:
                value = new_score
                best_col = col
            beta = min(beta, value)
            if alpha >= beta:
                break
        return best_col, value

# ----------------------------
# MAIN GAME LOOP
# ----------------------------
def play_game():
    board = create_game_board()
    game_over = False
    turn = random.choice([PLAYER_AI, PLAYER_RANDOM])
    outcomes = []
    total_nodes = []
    total_time = []

    print("Game Start!\n")

    while not game_over:
        print_board(board)

        if turn == PLAYER_AI:
            node_counter = [0]
            start_time = time.time()
            move, _ = minimax(board, SEARCH_DEPTH, -math.inf, math.inf, True, node_counter)
            elapsed_time = time.time() - start_time
            total_time.append(elapsed_time)
            total_nodes.append(node_counter[0])

            if move is not None and is_valid_move(board, move):
                row = get_next_open_row(board, move)
                drop_disc(board, row, move, PLAYER_AI)
                print(f"AI placed in column {move}")
            else:
                print("AI skipped (no valid moves)")

            if check_winner(board, PLAYER_AI):
                print("AI wins!")
                outcomes.append("Win")
                game_over = True
            elif is_board_full(board):
                print("It's a Draw!")
                outcomes.append("Draw")
                game_over = True
            turn = PLAYER_RANDOM

        else:
            # Random move (you can replace with human input)
            valid_cols = get_valid_moves(board)
            move = random.choice(valid_cols)
            row = get_next_open_row(board, move)
            drop_disc(board, row, move, PLAYER_RANDOM)
            print(f"Random Player placed in column {move}")

            if check_winner(board, PLAYER_RANDOM):
                print("Random Player wins!")
                outcomes.append("Lose")
                game_over = True
            elif is_board_full(board):
                print("It's a Draw!")
                outcomes.append("Draw")
                game_over = True
            turn = PLAYER_AI

    print_board(board)
    print("\n--- Game Summary ---")
    print(f"Nodes Expanded per move: {total_nodes}")
    print(f"Average Nodes Expanded: {sum(total_nodes)/len(total_nodes):.2f}")
    print(f"Average Runtime per move: {sum(total_time)/len(total_time):.4f} seconds")
    print(f"Outcome: {outcomes[-1]}")

# ----------------------------
# RUN GAME
# ----------------------------
if __name__ == "__main__":
    play_game()
