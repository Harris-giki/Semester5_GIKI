#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <time.h>
#include <string.h>

#define N 10000000

// Helper to print thread config
void print_config(int thread_count) {
    printf("\n========== Running with %d threads ==========\n", thread_count);
}

// Sequential baseline sum
double sequential_sum(long *arr, long sz) {
    double start_t = omp_get_wtime();
    long long total = 0;
    for(long idx = 0; idx < sz; idx++) {
        total += arr[idx];
    }
    double end_t = omp_get_wtime();
    printf("Sequential sum: %lld (took %.6f seconds)\n", total, end_t - start_t);
    return end_t - start_t;
}

// Parallel sum with reduction
double parallel_sum(long *arr, long sz, int threads, long long *result) {
    omp_set_num_threads(threads);
    long long total = 0;
    
    double start_t = omp_get_wtime();
    #pragma omp parallel for reduction(+:total)
    for(long idx = 0; idx < sz; idx++) {
        total += arr[idx];
    }
    double end_t = omp_get_wtime();
    
    *result = total;
    double elapsed = end_t - start_t;
    printf("Parallel sum (%d threads): %lld (took %.6f seconds)\n", 
           threads, total, elapsed);
    return elapsed;
}

// Synthetic workload with varying computation per iteration
void synthetic_workload(long sz, int threads, const char *schedule_type) {
    omp_set_num_threads(threads);
    long long accumulator = 0;
    
    double start_t = omp_get_wtime();
    
    if(strcmp(schedule_type, "static") == 0) {
        #pragma omp parallel for schedule(static) reduction(+:accumulator)
        for(long idx = 0; idx < sz; idx++) {
            long inner_limit = (idx % 1000) + 1;
            for(long j = 0; j < inner_limit; j++) {
                accumulator += (idx * j) % 7;
            }
        }
    }
    else if(strcmp(schedule_type, "dynamic") == 0) {
        #pragma omp parallel for schedule(dynamic, 100) reduction(+:accumulator)
        for(long idx = 0; idx < sz; idx++) {
            long inner_limit = (idx % 1000) + 1;
            for(long j = 0; j < inner_limit; j++) {
                accumulator += (idx * j) % 7;
            }
        }
    }
    else if(strcmp(schedule_type, "guided") == 0) {
        #pragma omp parallel for schedule(guided) reduction(+:accumulator)
        for(long idx = 0; idx < sz; idx++) {
            long inner_limit = (idx % 1000) + 1;
            for(long j = 0; j < inner_limit; j++) {
                accumulator += (idx * j) % 7;
            }
        }
    }
    
    double end_t = omp_get_wtime();
    printf("%s schedule (%d threads): result=%lld, time=%.6f sec\n", 
           schedule_type, threads, accumulator, end_t - start_t);
}

int main() {
    printf("Initializing array of %d elements...\n", N);
    
    long *data_arr = (long *)malloc(N * sizeof(long));
    if(!data_arr) {
        fprintf(stderr, "Memory allocation failed\n");
        return 1;
    }
    
    // Initialize with modulo pattern
    for(long idx = 0; idx < N; idx++) {
        data_arr[idx] = idx % 100;
    }
    
    printf("\n=== PART 1: Reduction Sum ===\n");
    
    double seq_time = sequential_sum(data_arr, N);
    
    int thread_configs[] = {1, 2, 4, 8};
    int num_configs = 4;
    
    FILE *csv_file = fopen("results/measurements.csv", "w");
    if(!csv_file) {
        fprintf(stderr, "Could not create CSV file\n");
        free(data_arr);
        return 1;
    }
    
    fprintf(csv_file, "Threads,Time(s),Speedup,Efficiency\n");
    
    for(int cfg = 0; cfg < num_configs; cfg++) {
        int thr_count = thread_configs[cfg];
        print_config(thr_count);
        
        long long par_result;
        double par_time = parallel_sum(data_arr, N, thr_count, &par_result);
        
        double speedup_val = seq_time / par_time;
        double efficiency_val = speedup_val / thr_count;
        
        printf("Speedup: %.3f, Efficiency: %.3f\n", speedup_val, efficiency_val);
        fprintf(csv_file, "%d,%.6f,%.3f,%.3f\n", 
                thr_count, par_time, speedup_val, efficiency_val);
    }
    
    fclose(csv_file);
    
    printf("\n=== PART 2: Scheduling Comparison ===\n");
    long workload_sz = N / 100;
    
    printf("\nTesting with 4 threads:\n");
    synthetic_workload(workload_sz, 4, "static");
    synthetic_workload(workload_sz, 4, "dynamic");
    synthetic_workload(workload_sz, 4, "guided");
    
    printf("\n[Analysis]\n");
    printf("Static: Good cache locality but poor load balance with varying work\n");
    printf("Dynamic: Better load balance, higher overhead from chunk assignment\n");
    printf("Guided: Adaptive chunks reduce overhead while maintaining balance\n");
    printf("Best choice: guided (balances overhead vs load distribution)\n");
    
    free(data_arr);
    printf("\nResults saved to results/measurements.csv\n");
    
    return 0;
}